﻿namespace Pixeval.Pages.Misc
{
    public sealed partial class DownloadAndHistoryListPage
    {
        public DownloadAndHistoryListPage()
        {
            this.InitializeComponent();
        }
    }
}
