﻿namespace Pixeval.Messages
{
    public record CommentRepliesHyperlinkButtonTappedMessage(object? Sender);
}