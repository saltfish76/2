﻿namespace Pixeval.Options
{
    public enum ThumbnailUrlOption
    {
        Large, Medium, SquareMedium
    }
}